<html>
<head>
		<meta charset="UTF-8">
		<title>Universidad</title>
	<style type="text/css">

body{
	margin: 0;
	background-color: #0A0E33;
}
#encabezado{
	width: 600px;
	height: 100px;
	background-color: #166A17;
	margin: 30px auto;
	font-size: 30px;
	text-align: center;
	line-height: 100px;
	color: #FFF;
}
#uno{
	width: 500px;
	height: 100px;
	background-color: #1F864C;
	margin: 0 auto;
	line-height: 100px;
	font-size: 50px;
	font-style: bold;
	text-align: center;
	margin-bottom: 15px;


}
#dos{
	border-radius: 10px;
	background-color: #1F864C;
	width: 350px;
	height: 300px;
	margin: 0 auto;
	padding: 40px;
	border-radius: 50px;
	text-align: right;

}
#tres{

	background-color: #1F864C;
	width: 55px;
	height: 5px;
	margin: 0 auto;
	padding: 40px;
	border-radius: 50px;
	text-align: center;
}

	</style>
</head>
<body>
	
	<div id="uno"><p>Pinfruit</p></div><br>
	<div id="dos"><form action="verificar.php" method="POST">

</div>
<div id="tres"><a href="login.php">Volver</a>
</div>
</body>
</html>
