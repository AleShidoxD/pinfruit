<html>
<head>
	<link rel="stylesheet" type="text/css" href="estilos.css">
	<meta charset="UTF-8">
	<title>HOME</title>
	<style type="text/css">
		img{
			width: 100px;
			height: 100px;
		}
	</style>
</head>
<body>
	<div id="uno"><a href="login.php"><div id="icono2"></div></a><div id="tit"><p>Pinfrut</p></div><a href="login.php"><div id="icono"></div></a></div><br>
	<div id="dos"><form action="verify.php" method="POST">
		<a href="myprofile.php"><img src="pics/perfil.jpg"></a>
	</div>
</body>
</html>