<html>
<head>
	<link rel="stylesheet" type="text/css" href="estilos.css">
	<meta charset="UTF-8">
	<title>MY PROFILE</title>
	<style type="text/css">

	#tabla1{
	margin-left: 0px;
	margin-top: 0px;
	width: 350px;
	height: 300px;
	text-align: center;
	font-size: 80px;

}
.td1{
	text-align: right;
}

a{
	color: black;
	text-decoration: none;
}
	</style>
</head>
<body>
	<div id="uno"><a href="logout.php"><div id="icono2"></div></a><div id="tit"><p>Pinfrut</p></div></div><br>
	<div id="dos">
		<table id="tabla1" border="0">
			<tr>
				<td class="td1"><a href="alta.php">Alta</a></td>
				<td><img src="pics/plus.png" width="120px" height="120px"></td>
			</tr>
				<tr>
				<td class="td1"><a href="baja.php">Baja</a></td>
				<td><img src="pics/minus.png" width="100px" height="100px"></td>
			</tr>

		</table>
	</div>
		
</body>
</html>